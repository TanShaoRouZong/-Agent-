"""
智能合同风险审查多Agent系统
Multi-Agent Contract Risk Analysis System

Architecture:
  Coordinator Agent → dispatches tasks
    ├── Parser Agent    → extracts structured info from contract
    ├── Risk Agent      → chain-of-thought risk assessment
    └── Summary Agent   → generates final report
"""

import os
import json
import time
import datetime
from agents.coordinator import CoordinatorAgent

SAMPLE_CONTRACT = """
服务合同

甲方：北京科技有限公司（以下简称"甲方"）
乙方：上海数据服务有限公司（以下简称"乙方"）

第一条 服务内容
乙方为甲方提供数据处理与分析服务，包括但不限于数据清洗、建模分析、报告输出。

第二条 服务期限
合同有效期自2025年1月1日至2025年12月31日，共12个月。

第三条 服务费用
总金额为人民币120万元，按季度支付，每季度30万元，乙方开具增值税专用发票。

第四条 保密条款
乙方须对甲方数据严格保密，保密期限为合同终止后5年。违反保密义务，乙方须赔偿甲方损失的50%，上限为10万元。

第五条 违约责任
任何一方违约，违约方须向守约方支付合同总金额5%的违约金，即6万元。

第六条 争议解决
本合同争议提交北京仲裁委员会仲裁，适用中国法律。

第七条 知识产权
乙方交付的所有成果物知识产权归甲方所有，乙方不得用于第三方。

第八条 不可抗力
因不可抗力导致合同无法履行，双方互不追责，但须在3日内书面通知对方。
"""


def print_banner():
    print("\n" + "="*60)
    print("  🤖 智能合同风险审查 Multi-Agent 系统")
    print("  Contract Risk Analysis — Powered by Claude API")
    print("="*60)
    print(f"  启动时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60 + "\n")


def main():
    print_banner()

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("❌ 错误: 请设置环境变量 ANTHROPIC_API_KEY")
        print("   export ANTHROPIC_API_KEY=your_key_here")
        return

    print("📄 输入合同文本已加载 (示例合同，共8条款)\n")
    time.sleep(0.5)

    coordinator = CoordinatorAgent(api_key=api_key)
    result = coordinator.run(SAMPLE_CONTRACT)

    # Save output
    output_path = f"output/report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"\n✅ 完整报告已保存至: {output_path}")
    print("\n" + "="*60)
    print("  任务完成 — All Agents Finished")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
